﻿namespace CrossExchange
{
    public interface ITradeRepository : IGenericRepository<Trade>
    {
    }
}