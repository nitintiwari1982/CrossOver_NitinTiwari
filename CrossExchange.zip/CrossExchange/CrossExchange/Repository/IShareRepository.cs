﻿namespace CrossExchange
{
    public interface IShareRepository : IGenericRepository<HourlyShareRate>
    {
      
    }
}